﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Controller for group C
namespace JamFactory.Controller {
    class DevelopmentController {
    }
}
