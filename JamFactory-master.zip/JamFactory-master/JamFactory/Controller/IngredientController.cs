﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Controller for group A
namespace JamFactory.Controller {
    class IngredientController {

        public void TestMetode()
        {
            // Hej spassere lmao may may 
            //Hey
            // 100
        }
    }
}
